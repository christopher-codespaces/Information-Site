import React from "react"

export default function Logo () {
    return (
        <aside>
            <div class="logo-container">
                <h1>Welcome to My Website</h1>
                
                </div>
        </aside>
    )
}