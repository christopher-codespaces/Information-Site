import React from "react"
import Navbar from "./components/Navbar"
import Content from "./components/Content"
import Logo from "./components/Logo"


export default function App() {
    return (
        <div className="container">
            <Navbar />
            
            <Content />
        </div>
    )
}